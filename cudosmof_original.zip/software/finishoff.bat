cd %1
echo off
:Repeat
del uninstall.exe
if exist uninstall.exe goto Repeat
cd ..
rmdir /S /Q %1
ECHO Successfully uninstalled the fibre software package. You may close this window.
exit

