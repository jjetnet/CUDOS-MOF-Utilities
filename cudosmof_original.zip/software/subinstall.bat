RUNDLL32.exe setupapi.dll,InstallHinfSection DefaultInstall 132 .\install.inf

